
public class ���ڿ͹��ڿ� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char q = '3';
		System.out.println(q);
		
		String s = "";
		System.out.println(s);

		String p = "" + 7 + 7;
		System.out.println(p);
		
		String qwe = 7 + 8+ "";
		System.out.println(qwe);
		
		String r = "1234";
		String f = "5678";
		String o = r + f;
		System.out.println(o);
	}

}
