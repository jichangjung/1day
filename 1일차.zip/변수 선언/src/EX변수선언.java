
public class EX�������� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 6, y = 3;
		System.out.println(x+y);
		System.out.println(x-y);
		System.out.println(x*y);
		System.out.println(x/y);

	}

}
