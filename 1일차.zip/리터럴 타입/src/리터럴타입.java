
public class ���ͷ�Ÿ�� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		boolean i = true;
		System.out.println(i);
		
		long j = 128l;
		System.out.println(j);
		
		int n = 0b10100101;
		System.out.println(n);
		
		int m = 0x01;
		System.out.println(m);
		
		float fly = 3.14f;
		System.out.println(fly);
		
		double num = 0.1595357;
		System.out.println(num);
		
		long v = 100000000000000l;
		System.out.println(v);
		
		
		System.out.println(10.);
		System.out.println(.10);
		System.out.println(10f);
		System.out.println(1e4);

		
		
		
	}

}
