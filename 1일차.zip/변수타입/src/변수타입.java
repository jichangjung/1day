
public class ����Ÿ�� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int age = 25;
		//age = 26;
		//age = 55;
		System.out.println(age);

	}

}
